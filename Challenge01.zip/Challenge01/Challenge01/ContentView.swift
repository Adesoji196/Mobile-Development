//
//  ContentView.swift
//  Challenge01
//
//  Created by Turma02-1 on 15/10/26.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            HStack{
                Rectangle()
                    .foregroundStyle(.red)
                    .frame(width:100,height:100)
                    .padding()
                
                Spacer()
                Rectangle()
                    .foregroundStyle(.blue)
                    .frame(width:100,height:100)
                    .padding()
            }
                
                Spacer()
            
            HStack{
                Rectangle()
                .foregroundStyle(.green)
                .frame(width:100,height:100)
                .padding()
                
                Spacer()
                Rectangle()
                .foregroundStyle(.yellow)
                .frame(width:100,height:100)
                .padding()
                
                
                    
                
                
                
                    
            }
            
            
        }
    }
}

#Preview {
    ContentView()
}
