//
//  Challenge01App.swift
//  Challenge01
//
//  Created by Turma02-1 on 15/10/26.
//

import SwiftUI

@main
struct Challenge01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
